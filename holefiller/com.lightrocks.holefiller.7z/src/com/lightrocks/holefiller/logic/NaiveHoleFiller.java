package com.lightrocks.holefiller.logic;

import com.lightrocks.holefiller.Consts;
import com.lightrocks.holefiller.Edges;
import com.lightrocks.holefiller.Point;
import com.lightrocks.holefiller.interfaces.HoleFiller;
import com.lightrocks.holefiller.interfaces.WeightingLogic;

public class NaiveHoleFiller implements HoleFiller {
	/* (non-Javadoc)
	 * @see com.lightricks.holefiller.HoleFiller#fillHole(int[][], com.lightricks.holefiller.Edges, com.lightricks.holefiller.interfaces.WeightingLogic)
	 */
	@Override
	public void fillHole(double[][] image, Edges edges, WeightingLogic<?> weightingLogic) {
		for (int i = edges.min.x; i <= edges.max.x; i++) {
			for (int j = edges.min.y; j <= edges.max.y; j++) {
				if (image[i][j] == Consts.INVALID) {				
					Point ij = new Point(i, j);
					double weightedValueSum = 0;
					double weightSum = 0;
					
					for (Point p : edges.edgePoints.values()) {
						double weight = weightingLogic.weight(p, ij);
						weightedValueSum += weight*p.value;
						weightSum += weight;
					}
					
					image[i][j] = weightedValueSum/weightSum;
				}
				//System.out.print(image[i][j] + " ");
			}
			//System.out.println("");
		}		
	}
}
