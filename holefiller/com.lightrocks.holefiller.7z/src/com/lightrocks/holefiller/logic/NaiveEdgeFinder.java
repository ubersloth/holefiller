package com.lightrocks.holefiller.logic;

import com.lightrocks.holefiller.Consts;
import com.lightrocks.holefiller.Edges;
import com.lightrocks.holefiller.Point;

public class NaiveEdgeFinder{
	/* (non-Javadoc)
	 * @see com.lightricks.holefiller.EdgeFinder#findEdges(int[][])
	 */
	public Edges findEdges(double[][] image) {
		Edges e = new Edges();

		// Runtime complexity is m*n of matrix
		for (int row = 0; row < image.length; row++) {
			for (int col = 0; col < image[0].length; col++) {
				if (image[row][col] != Consts.INVALID) {
					edgesearch: for (int i = Math.max(row-1, 0); i <= Math.min(row+1, image.length-1); i++) {
						for (int j = Math.max(col-1, 0); j <= Math.min(col+1, image[0].length-1); j++) {
							if (image[i][j] == Consts.INVALID) {
								Point edgePoint = new Point(row, col, image[row][col]);
								e.edgePoints.put(edgePoint, edgePoint);
								e.min.x = Math.min(e.min.x, row);
								e.min.y = Math.min(e.min.y, col);
								e.max.x = Math.max(e.max.x, row);
								e.max.y = Math.max(e.max.y, col);
								
								break edgesearch;
							}
						}
					}
				}
			}
		}
				
		return e;
	}
}
