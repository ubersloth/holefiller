package com.lightrocks.holefiller;

import java.io.IOException;

import com.lightrocks.holefiller.interfaces.HoleFiller;
import com.lightrocks.holefiller.logic.DistanceWeightingArgs;
import com.lightrocks.holefiller.logic.DistanceWeightingLogic;
import com.lightrocks.holefiller.logic.NaiveEdgeFinder;
import com.lightrocks.holefiller.logic.NaiveHoleFiller;

public class Main {

	public static void main(String[] args) throws IOException, InstantiationException, IllegalAccessException, ClassNotFoundException {
		ArgsMapper argsMapper = new ArgsMapper(args);
		
		if (!argsMapper.map.containsKey(Consts.IMAGE_ARG) || argsMapper.map.get(Consts.IMAGE_ARG).isEmpty()) {
			System.out.println("Input image required");
			System.out.println(Consts.USAGE_EXAMPLE);
			return;			
		}
		
		HoleFiller holeFiller = null;
		
		if (!argsMapper.map.containsKey(Consts.HOLE_FILLER_ARG)) {
			holeFiller = new NaiveHoleFiller();
		}
		else {
			holeFiller = (HoleFiller)Class.forName("com.lightrocks.holefiller.logic." + argsMapper.map.get(Consts.HOLE_FILLER_ARG)).newInstance();
		}

		ImageOpertaions im = new ImageOpertaions();
		double image[][] = im.load(argsMapper.map.get(Consts.IMAGE_ARG));
				
		DistanceWeightingArgs weightingArgs = new DistanceWeightingArgs();
		weightingArgs.parseArgs(argsMapper);
		DistanceWeightingLogic weightingLogic = new DistanceWeightingLogic();
		weightingLogic.initArgs(new DistanceWeightingArgs());
		
		NaiveEdgeFinder nef = new NaiveEdgeFinder();
		Edges edges = nef.findEdges(image);	
		
		/*HoleFiller nhf = new ProximityHoleFiller();
		nhf.fillHole(image, e, dw);*/
		
		//print(image);
		
		holeFiller.fillHole(image, edges, weightingLogic);
		
		im.save(image, "testrun" + System.currentTimeMillis() + ".png");
		
		/*Edges k = new Edges();
		k.min.y = 10;
		k.max.y = 100;
		k.min.x = 20;
		k.max.x = 50;
		
		dw.createWeightingGroups(4, e);*/
	}
	
	public static void print(double[][] image) {
		System.out.println("");

		for (int row = 0; row < image.length; row++) {
			for (int col = 0; col < image[0].length; col++) {
				System.out.print(String.format("%.5f", image[row][col]) + " ");
			}
			System.out.println("");
		}
	}
	
	public void old() {
		/*double image[][] = {
	      { 0.75, 0.100, 0.125, 0.150, 0.175, 0.200, 0.225, 0.250 },
	      { 0.75, 0.100, 0.125, 0.150, 0.175, 0.200, 0.225, 0.250 },
	      { 0.75, 0.100, 0.125, 0.150, 0.175, 0.200, 0.225, 0.250 },
	      { 0.75, 0.100, 0.125, 0.150, 0.175, 0.200, 0.225, 0.250 },
	      { 0.75, 0.100, 0.125,    -1,    -1, 0.200, 0.225, 0.250 },
	      { 0.75, 0.100, 0.125, 0.150,    -1,    -1, 0.225, 0.250 },
	      { 0.75, 0.100, 0.125,    -1,    -1,    -1, 0.225, 0.250 },
	      { 0.75, 0.100,    -1,    -1,    -1, 0.200, 0.225, 0.250 },
	      { 0.75, 0.100, 0.125, 0.150,    -1,    -1, 0.225, 0.250 },
	      { 0.75, 0.100, 0.125, 0.150, 0.175,    -1, 0.225, 0.250 },
	      { 0.75, 0.100, 0.125, 0.150, 0.175, 0.200, 0.225, 0.250 },
	      { 0.75, 0.100, 0.125, 0.150, 0.175, 0.200, 0.225, 0.250 },
	      { 0.75, 0.100, 0.125, 0.150, 0.175, 0.200, 0.225, 0.250 },
		};*/

		/*double image[][] = {
		      { 0.75, 0.100, 0.125, 0.150, 0.175, 0.200, 0.225, 0.250 },
		      { 0.75, 0.100, 0.125, 0.150, 0.175, 0.200, 0.225, 0.250 },
		      { 0.75, 0.100, 0.125, 0.150, 0.175, 0.200, 0.225, 0.250 },
		      { 0.75, 0.100, 0.125, 0.150, 0.175, 0.200, 0.225, 0.250 },
		      { 0.75, 0.100, 0.125,    -1,    -1, 0.200, 0.225, 0.250 },
		      { 0.75, 0.100, 0.125, 0.150, 0.175, 0.200, 0.225, 0.250 },
		      { 0.75, 0.100, 0.125, 0.150, 0.175, 0.200, 0.225, 0.250 },
		      { 0.75, 0.100, 0.125, 0.150, 0.175, 0.200, 0.225, 0.250 },
		};	*/		
	}
}
