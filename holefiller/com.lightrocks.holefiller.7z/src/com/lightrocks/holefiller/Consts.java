package com.lightrocks.holefiller;

// Making this static is not a best practice for mocking, ideally we'd use a single instance with injection
public class Consts {
	public static final double INVALID = -1;
	public static final int	   PROXIMITY = 20;
	
	public static final String HOLE_FILLER_ARG = "holefiller";
	public static final String IMAGE_ARG = "image";
	
	public static final String USAGE_EXAMPLE = "Usage example: -image test.png [-holefiller NaiveHoleFiller -factor 2 -safedivisor 0.0000001]";
}
