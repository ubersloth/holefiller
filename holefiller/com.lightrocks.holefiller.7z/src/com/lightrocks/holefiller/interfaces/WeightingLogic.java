package com.lightrocks.holefiller.interfaces;

import java.util.List;

import com.lightrocks.holefiller.Edges;
import com.lightrocks.holefiller.Point;

public interface WeightingLogic<T extends WeightingArgs> {
	void initArgs(T weightingArgs);
	double weight(Point a, Point b);
	List<WeightingGroup> createWeightingGroups(double howMany, Edges edges);
}
