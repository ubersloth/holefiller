package com.lightrocks.holefiller.interfaces;

import com.lightrocks.holefiller.ArgsMapper;

public interface WeightingArgs {
	void parseArgs(ArgsMapper mapper);
}
